# CoC Builder Base Farming Assistant (Android)

A small Android starter app that uses on-device Google ML Kit text recognition to read text from a screenshot selected by the user, suggests candidate Gold/Elixir amounts, and calculates a simple manually-configured target estimate. It does not automate Clash of Clans, interact with the game, or deploy troops.

## Requirements
- Android Studio (recommended) or an Android IDE capable of building Gradle Android projects
- JDK 17
- Android SDK platform 35
- Internet connection for Gradle to download dependencies on first build

## Build APK with Android Studio
1. Extract this project ZIP.
2. In Android Studio choose **Open** and select the `CoCBuilderAssistant` folder.
3. Allow Gradle sync and install any requested Android SDK platform 35 components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually written to `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone, open it, and allow installation from that source if Android asks.

## Use on Android
1. Open the app and tap **Pilih screenshot untuk OCR**.
2. Select a screenshot from the Builder Base versus/reward screen.
3. Check the detected text and correct Gold/Elixir fields manually if needed. OCR is heuristic and can misread icons or numbers.
4. Enter your estimated troop costs and chance of winning, then tap **Hitung rekomendasi target**.

## Important limitations
- This starter version does not capture the live screen automatically; you select an existing screenshot via Android's document picker.
- OCR parsing is heuristic and the numbers must be checked.
- Reward and cost semantics in Builder Base may differ from what is shown on a particular screen; use only numbers you understand.
- It does not automate finding opponents, tapping game controls, or attacking. Keep gameplay manual and check Supercell's current terms.
- The app requires internet only to download its ML Kit dependency during build; text recognition runs on-device after install.
