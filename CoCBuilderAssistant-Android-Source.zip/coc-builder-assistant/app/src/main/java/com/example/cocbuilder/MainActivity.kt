package com.example.cocbuilder

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class MainActivity : Activity() {
    private val pickImageCode = 1001
    private lateinit var goldInput: EditText
    private lateinit var elixirInput: EditText
    private lateinit var costGoldInput: EditText
    private lateinit var costElixirInput: EditText
    private lateinit var winChanceInput: EditText
    private lateinit var output: TextView
    private lateinit var rawText: TextView
    private var latestBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 28, 36, 36)
        }
        scroll.addView(layout)

        fun label(text: String) {
            layout.addView(TextView(this).apply {
                this.text = text
                textSize = 16f
                setPadding(0, 18, 0, 6)
            })
        }
        fun field(hint: String, default: String = "0"): EditText {
            val edit = EditText(this).apply {
                this.hint = hint
                setSingleLine(true)
                setText(default)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            layout.addView(edit, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            return edit
        }
        fun button(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        layout.addView(TextView(this).apply {
            text = "Builder Base Farming Assistant"
            textSize = 23f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        })
        layout.addView(TextView(this).apply {
            text = "Pilih screenshot layar versus/reward. OCR berjalan di perangkat; periksa angka sebelum menghitung. Serangan tetap manual."
            textSize = 14f
        })
        button("Pilih screenshot untuk OCR") { chooseImage() }
        rawText = TextView(this).apply {
            text = "Teks OCR akan muncul di sini."
            textSize = 13f
            setPadding(0, 12, 0, 12)
        }
        layout.addView(rawText)

        label("Gold reward (cek dan koreksi hasil OCR)")
        goldInput = field("Gold", "0")
        label("Elixir reward (cek dan koreksi hasil OCR)")
        elixirInput = field("Elixir", "0")
        label("Perkiraan biaya pasukan Gold (opsional)")
        costGoldInput = field("Biaya Gold", "0")
        label("Perkiraan biaya pasukan Elixir (opsional)")
        costElixirInput = field("Biaya Elixir", "0")
        label("Perkiraan peluang menang (0–100)")
        winChanceInput = field("Peluang menang", "70")

        button("Hitung rekomendasi target") { calculate() }
        output = TextView(this).apply {
            text = "Hasil analisis akan tampil di sini."
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        layout.addView(output)
        setContentView(scroll)
    }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, pickImageCode)
    }

    @Deprecated("Uses the compatible activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImageCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bitmap = loadBitmap(uri)
            latestBitmap = bitmap
            runOcr(bitmap)
        } catch (e: Exception) {
            rawText.text = "Gagal membuka gambar: ${e.localizedMessage}"
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        return if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = false
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        }
    }

    private fun runOcr(bitmap: Bitmap) {
        rawText.text = "Membaca screenshot…"
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text
                rawText.text = "Teks terdeteksi:\n$text\n\nPeriksa angka; OCR bisa keliru."
                val parsed = parseResources(text)
                parsed.first?.let { goldInput.setText(it.toString()) }
                parsed.second?.let { elixirInput.setText(it.toString()) }
            }
            .addOnFailureListener { e ->
                rawText.text = "OCR gagal: ${e.localizedMessage}"
            }
            .addOnCompleteListener { recognizer.close() }
    }

    private fun parseResources(text: String): Pair<Long?, Long?> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var gold: Long? = null
        var elixir: Long? = null
        for (i in lines.indices) {
            val line = lines[i].lowercase(Locale.ROOT)
            val candidates = mutableListOf(lines[i])
            if (i + 1 < lines.size) candidates.add(lines[i + 1])
            if (i > 0) candidates.add(lines[i - 1])
            val numbers = candidates.flatMap { s ->
                Regex("(?<![A-Za-z])\\d[\\d,.]*").findAll(s).mapNotNull {
                    it.value.replace(",", "").replace(".", "").toLongOrNull()
                }.toList()
            }
            if (numbers.isNotEmpty() && (line.contains("gold") || line.contains("g0ld"))) {
                gold = numbers.first()
            }
            if (numbers.isNotEmpty() && (line.contains("elixir") || line.contains("elix"))) {
                elixir = numbers.first()
            }
        }
        return Pair(gold, elixir)
    }

    private fun calculate() {
        val gold = goldInput.asLong()
        val elixir = elixirInput.asLong()
        val costGold = costGoldInput.asLong()
        val costElixir = costElixirInput.asLong()
        val chance = winChanceInput.asLong().coerceIn(0, 100)
        val expectedGold = ((gold - costGold).coerceAtLeast(0) * chance) / 100.0
        val expectedElixir = ((elixir - costElixir).coerceAtLeast(0) * chance) / 100.0
        val total = expectedGold + expectedElixir
        val recommendation = when {
            gold + elixir == 0L -> "Belum ada data reward. Pilih screenshot atau isi angka."
            chance >= 70 && total > 0 -> "Layak dipertimbangkan; pastikan base dan pasukan cocok."
            chance >= 40 -> "Risiko sedang; bandingkan dengan target lain."
            else -> "Risiko tinggi; pertimbangkan melewati target."
        }
        output.text = "Perkiraan hasil berbobot peluang menang:\n" +
            "Gold: ${"%,.0f".format(Locale.US, expectedGold)}\n" +
            "Elixir: ${"%,.0f".format(Locale.US, expectedElixir)}\n\n" + recommendation +
            "\n\nIni hanya estimasi sederhana, bukan prediksi resmi."
    }

    private fun EditText.asLong(): Long = text.toString().trim().replace(",", "").toLongOrNull() ?: 0L
}
